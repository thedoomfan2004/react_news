import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';



const API_KEY = '0d6e0bb7dabb4f8fac9a8680b34e096f';
const API_URL = 'https://newsapi.org/v2/everything';
export default function Search( {handleDataChange} ) {



  const [searchTerm, setSearchTerm] = useState('');
  const [articles, setArticles] = useState([]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const url = `${API_URL}?q=${searchTerm}&sortBy=popularity&apiKey=${API_KEY}`;
    const response = await fetch(url);
    const data = await response.json();
    setArticles(data.articles);
    handleDataChange('articles')
  };

  return (
    <div className='w-full h-10 flex justify-start'>
        <form onSubmit={handleSubmit}>
        <label>
          <input type="text" value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} 
          className='  border-2 border-gray-400 
          rounded-md text-base p-2 h-10 w-44 focus:outline-none focus:border-blue-500' 
          placeholder='Search for news'
          />
        </label>
        <button type="submit" className='bg-blue-500 absolute xl:right-4
         hover:bg-blue-700 right-12 text-white text-xs w-12 h-10 rounded-r-md'>
        <Link to={'/bySearch'}>Search</Link>
        </button>
      </form>
    
        
    </div>
  )
}

