import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import  logo  from './assets/logo.jpg'
import menu from './assets/menu.png'
import Search from './Search'

export default function Nav( {handleDataChange} ) {

  const [selected, setSelected] = useState('tech')
  const [isnav, setIsnav] = useState(false)

  function navv() {
    setIsnav(isnav ? false : true)
  }


  function select(e) {
    setSelected(e)
  }

  return (
    <>
      <img src={menu} alt="" onClick={navv} className='w-6 
      cursor-pointer fixed right-full xl:right-3 z-10' />
      <div className={`w-56 flex fixed  ${isnav ? 'navv' : 'xl:-left-full left-3'} duration-150 transition-all
        flex-col text-2xl gap-5 font-light`}
      >
        <img src={logo}  alt="" className='w-28' />
        <Link onClick={() => select('tech')} className={`hover:text-green-500 
        ${selected == 'tech' ? 'text-red-600' : ''}`} to={'/'}>Tech News</Link>

        <Link onClick={() => select('tesla')} className={`hover:text-green-500 
        ${selected == 'tesla' ? 'text-red-600' : ''}`} to={'/tesla'} >Tesla News</Link>
        
        <Link onClick={() => select('apple')} className={`hover:text-green-500 
        ${selected == 'apple' ? 'text-red-600' : ''}`} to={'/apple'}>Apple News</Link>

        <Link onClick={() => select('us')} className={`hover:text-green-500 
        ${selected == 'us' ? 'text-red-600' : ''}`} to={'/us'}>U.S News</Link>

        <Link onClick={() => select('wall')} className={`hover:text-green-500 
        ${selected == 'wall' ? 'text-red-600' : ''}`} to={'/wallstreet'}>Wall streeet News</Link>
        <Search handleDataChange={handleDataChange} />
      </div>
    </>
    
  )
}