import React from 'react'
import { Route, Routes } from 'react-router-dom'
import News from './News'
import Nav from './Nav'


export default function App() {
  return (
    <div className='overflow-hidden'>
      <div className='flex gap-4 justify-center p-7'>
        <Nav />
        <Routes>
          <Route path='/' element={<News />} />
        </Routes>   
      </div>
      <div className='w-screen h-16 bg-black gap-1 text-white justify-center flex items-center'>
          by <a href="" className='underline'>UmidGafur</a> 
      </div>
    </div>
  )
}
