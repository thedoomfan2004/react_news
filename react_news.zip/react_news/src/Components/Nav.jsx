import React from 'react'
import { Link } from 'react-router-dom'
import  logo  from './assets/logo.jpg'

export default function Nav() {
  return (
    <div className='w-56 flex fixed left-3 flex-col text-2xl gap-5 font-light'>
      <img src={logo} alt="" className='w-28' />
      <Link className='hover:text-green-500' to={'/super'}>Tech News</Link>
      <Link className='hover:text-green-500' to={'/'}>Tesla News</Link>
      <Link className='hover:text-green-500' to={'/'}>Apple News</Link>
      <Link className='hover:text-green-500' to={'/'}>U.S News</Link>
      <Link className='hover:text-green-500' to={'/'}>Wall streeet News</Link>
    </div>
  )
}