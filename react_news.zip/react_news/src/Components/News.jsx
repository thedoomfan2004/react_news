import React, { useState, useEffect } from 'react';

function News() {
  const [news, setNews] = useState([]);

  useEffect(() => {
    const fetchNews = async () => {
      const response = await fetch(`https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=0d6e0bb7dabb4f8fac9a8680b34e096f`);
      const data = await response.json();
      setNews(data.articles);
      setHead(data)
    };
    fetchNews();
  }, []);

  console.log(news)

  return (
    <div className='w-9/12 flex flex-col' >
      <div className="">
        {news.map((item, key) => (
        <div className='font-extrabold flex
         gap-5 border-t pt-5 pb-5 border-b text-xl' 
         key={key}>
          {/* {item.author} */}
          <div className="text-2xl flex-col flex gap-4" style={{width: '500px'}}>
            {item.title}
            <p className='text-base text-blue-500 font-medium'>
              {item.author}
              <br />
            <span className='font-thin text-emerald-500'>
              {item.publishedAt}
            </span> 
            </p>
          </div>        
          <div className="text-base w-2/4 font-normal">
            {item.description}
          </div>     
          <img src={item.urlToImage} alt="" className='w-64 shadow-2xl'/>     
        </div>
        ))}
      </div>
      
    </div>
  );
}

export default News;