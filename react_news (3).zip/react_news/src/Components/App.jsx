import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Technews from './News'
import Nav from './Nav'
import AppleNews from './AppleNews'
import UsNews from './UsNews'
import TeslaNews from './TeslaNews'
import Wallnews from './WallNews'
import bottom from './assets/bottom.svg'
import git from './assets/git.svg'
import loading from "./assets/loading.gif";


export default function App() {
  return (
    <div className='overflow-x-hidden bg-slate-50 flex flex-col w-screen justify-between h-screen'>
      <div className='flex gap-4 bg-slate-50 xl:justify-start z-10 justify-center p-7'>
        <Nav />
        <Routes>
          <Route path='/' element={<Technews />} />
          <Route path='/apple' element={<AppleNews />} />
          <Route path='/us' element={<UsNews />} />
          <Route path='/tesla' element={<TeslaNews />} />
          <Route path='/wallstreet' element={<Wallnews />} />
        </Routes>   
      </div>
      <a href="#bottom">
        <img src={bottom} alt="" className='fixed z-20 bottom-20 bg-white rounded-full md:right-3 right-12 md:w-10 w-16 ' />
      </a>
      <div className="w-screen h-screen z-0 absolute flex items-center justify-center">
        <img src={loading} alt="" className='w-56' />
      </div>
      
      <div className='w-screen md:p-5 h-20 bg-black gap-1 p-2 md:text-xs text-white justify-center flex items-center'>   
        This website was made with using 
          <a href="https://newsapi.org/" target={'_blank'} id='bottom' className='underline mr-3 cursor-pointer text-blue-500'>News Api Org.</a> 
          by 
        <a href="https://github.com/thedoomfan2004" target={'_blank'} id='bottom' className='underline cursor-pointer mr-3'>UmidGafur</a> 
        <a href="https://github.com/thedoomfan2004/react_news">
          <img src={git} alt="" className='w-8 brightness-200' />
        </a>
      </div>
    </div>
  )
}