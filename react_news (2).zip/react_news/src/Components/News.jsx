import React, { useState, useEffect } from 'react';

function Technews() {
  const [news, setNews] = useState([]);
  const [head, setHead] = useState(null)
  const [popup, setPopup] = useState(false)


  useEffect(() => {
    const fetchNews = async () => {
      const response = await fetch(`https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=0d6e0bb7dabb4f8fac9a8680b34e096f`);
      const data = await response.json();
      if(response) {
        setNews(data.articles);
        setHead(data.articles[9]);
      } else {
        // console.log(error)
        return
      }
      
    };
    fetchNews();
  }, []);

  // console.log(head)

  function pop() {
    setPopup(popup == true ? false : true)
  }

  if (!news) {
    return <div>Loading...</div>;
  } 

  return (
    <div className='w-9/12 flex flex-col xl:w-10/12'>

       <div className="w-full gap-5 h-fit pt-5 sm:pb-8 sm:gap-2 pb-16 sm:flex-col flex">
        <div className="flex flex-col sm:w-full w-6/12">
          <h1 className='text-4xl xl:text-2xl mb-5 font-extrabold'>
            {head && head.title}
          </h1>
          <div className='flex gap-3 md:text-sm text-red-600'>
            <p className='text-blue-500 '>
              {head && head.author}
            </p>           
             {head && head.publishedAt}
            </div> 
           <img src={head && head.urlToImage} alt="" className='w-full mt-2' />
          </div>
          <div className="w-2/6 sm:w-10/12 xl:text-base text-2xl">
              {head && head.description}
              <br />
              <br />
              <a target={'_blank'} className='text-green-500 xl:text-base 
              text-xl underline' href={head && head.url}>         
              Visit Page
            </a>
          </div>
        </div>       

        {news.map((item, key) => (
        <div className='font-extrabold flex gap-5 border-t lg:pt-2
         justify-between lg:pb-2 lg:gap-2 pt-5 lg:text-base pb-5 border-b' 
         key={key}>
          <div onClick={pop} className="text-2xl cursor-pointer lg:text-lg flex-col flex gap-4 sm:text-base" style={{width: '500px'}}>
            {item.title}
            <p className='text-base text-blue-500 font-medium'>
              {item.author}
              <br />
            <span className='font-thin text-emerald-500'>
              {item.publishedAt}
            </span> 
            </p>
          </div>        
          <div className="text-base w-2/4 font-normal lg:hidden">
            {item.description}
            <br />
            <br />
            <br />
            <a target={'_blank'} className='text-green-500 underline' href={item.url}>         
              Visit Page
            </a>
          </div>  
          {window.screen.width < 1020 ?
          <div onClick={pop} className={`absolute w-9/12 h-fit bg-white transition-all sm:p-3 bg-opacity-75 p-6 md:p-3 font-normal backdrop-blur-xl
           rounded-md ${popup  == true ? 'flex items-center' : 'hidden'} flex-col shadow-2xl`}>
            <div className="">
            {item.description}
            </div>
            <a target={'_blank'} className='text-green-500 underline' href={item.url}>         
              Visit Page
            </a>
          </div> 
          : ''}  
          <img src={item.urlToImage} alt="" className='shadow-2xl lg:w-48 lg:h-24
          sm:w-48 sm:h-16 w-64 h-36'/>     
        </div>
        ))}     
    </div>
  );
}

export default Technews;